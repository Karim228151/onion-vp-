#!/usr/bin/env node
// bot/bot.js - Telegram бот ONION VPN на telebot (node-telegram-bot-api)
// Поддерживает: подписку через TG Stars, реферальную систему, управление аккаунтом

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const TeleBot = require('telebot');
const fetch = require('node-fetch');
const { planHelpers, userHelpers, paymentHelpers, referralHelpers, db } = require('../db/database');

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const APP_URL = process.env.APP_URL || 'http://localhost:3000';
const BOT_SECRET = process.env.BOT_INTERNAL_SECRET || 'onion-internal-secret';
const bot = new TeleBot(TOKEN);

// ================================================
// УТИЛИТЫ
// ================================================
function formatDate(iso) {
  if (!iso) return 'бессрочно';
  const d = new Date(iso);
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function getUserByTgId(telegramId) {
  return userHelpers.findByTelegramId.get(telegramId);
}

function mainKeyboard() {
  return bot.keyboard([
    ['🌐 Подключиться к VPN', '💳 Купить подписку'],
    ['👥 Пригласить друга', '📊 Мой аккаунт'],
    ['❓ Помощь'],
  ], { resize: true });
}

// ================================================
// /start - стартовое сообщение + реферал
// ================================================
bot.on('/start', async (msg) => {
  const tgId = msg.from.id;
  const text = msg.text || '';
  const args = text.split(' ').slice(1);
  const refArg = args[0]; // "ref_ABCD1234"

  let user = getUserByTgId(tgId);

  // Если это реферальный старт и пользователь новый
  if (refArg && refArg.startsWith('ref_') && !user) {
    const refCode = refArg.replace('ref_', '').toUpperCase();
    // Авторизация пройдёт через веб-интерфейс, сохраняем ref в коде
    // Для бота — направляем к приложению с реферальным кодом
    await bot.sendMessage(tgId,
      `🎉 Тебя пригласил друг!\n\nПерейди в приложение, чтобы зарегистрироваться и получить бонус:\n\n👇`,
      { replyMarkup: bot.inlineKeyboard([[bot.button('inline', '🚀 Открыть ONION VPN', 'url', `${APP_URL}?ref=${refCode}`)]])}
    );
    return;
  }

  if (!user) {
    // Новый пользователь — направляем в приложение
    await bot.sendMessage(tgId,
      `👋 Добро пожаловать в *ONION VPN*!\n\nБезопасный и быстрый VPN через Telegram.\n\n🔐 Войди через Telegram, чтобы начать:`,
      {
        parseMode: 'Markdown',
        replyMarkup: bot.inlineKeyboard([[bot.button('inline', '🌐 Открыть приложение', 'url', APP_URL)]])
      }
    );
    return;
  }

  const planEmoji = user.plan === 'pro' ? '⭐ PRO' : '🆓 Free';
  const expires = user.plan === 'pro' ? `до ${formatDate(user.plan_expires_at)}` : '';

  await bot.sendMessage(tgId,
    `🧅 *ONION VPN*\n\n👤 ${user.first_name || user.username || 'Пользователь'}\n📦 План: ${planEmoji} ${expires}\n\nВыбери действие:`,
    { parseMode: 'Markdown', replyMarkup: mainKeyboard() }
  );
});

// ================================================
// 📊 Мой аккаунт
// ================================================
bot.on(/(📊 Мой аккаунт|\/account)/, async (msg) => {
  const user = getUserByTgId(msg.from.id);
  if (!user) return bot.sendMessage(msg.chat.id, '❌ Ты не зарегистрирован. Напиши /start');

  userHelpers.checkExpiry(user.id);
  const fresh = userHelpers.getById.get(user.id);
  const refCount = referralHelpers.countByReferrer.get(user.id).cnt;
  const usedGB = (fresh.traffic_used / 1073741824).toFixed(2);
  const limitGB = (fresh.traffic_limit / 1073741824).toFixed(0);
  const planEmoji = fresh.plan === 'pro' ? '⭐ PRO' : '🆓 Бесплатный';
  const expires = fresh.plan === 'pro' && fresh.plan_expires_at ? `\n⏳ Активен до: ${formatDate(fresh.plan_expires_at)}` : '';

  await bot.sendMessage(msg.chat.id,
    `📊 *Мой аккаунт*\n\n` +
    `👤 ${fresh.first_name || fresh.username}\n` +
    `🆔 ID: \`${fresh.telegram_id}\`\n` +
    `📦 План: ${planEmoji}${expires}\n` +
    `📶 Трафик: ${usedGB} GB / ${limitGB} GB\n` +
    `👥 Рефералов: ${refCount} чел.\n\n` +
    `🔗 Реф-ссылка:\n\`https://t.me/${process.env.TELEGRAM_BOT_USERNAME}?start=ref_${fresh.referral_code}\``,
    { parseMode: 'Markdown' }
  );
});

// ================================================
// 💳 Купить подписку
// ================================================
bot.on(/(💳 Купить подписку|\/buy)/, async (msg) => {
  const user = getUserByTgId(msg.from.id);
  if (!user) return bot.sendMessage(msg.chat.id, '❌ Напиши /start для начала');

  const plans = planHelpers.getAll.all();
  const buttons = plans.map(p => [
    bot.button('inline', `${p.name} — ${p.price_stars}⭐ / ${p.price_rub}₽`, 'callbackData', `buy_plan_${p.id}`)
  ]);
  buttons.push([bot.button('inline', '❌ Отмена', 'callbackData', 'cancel')]);

  await bot.sendMessage(msg.chat.id,
    `💳 *Выбери тариф ONION VPN PRO*\n\nВсе серверы, безлимитный трафик, максимальная скорость.\n\n_Оплата: ⭐ Telegram Stars или 💰 Рубли_`,
    { parseMode: 'Markdown', replyMarkup: bot.inlineKeyboard(buttons) }
  );
});

// ================================================
// Callback: buy_plan_X
// ================================================
bot.on('callbackQuery', async (query) => {
  const data = query.data;
  const tgId = query.from.id;
  const chatId = query.message.chat.id;
  const msgId = query.message.message_id;

  if (data === 'cancel') {
    await bot.answerCallbackQuery(query.id);
    await bot.deleteMessage(chatId, msgId).catch(() => {});
    return;
  }

  if (data.startsWith('buy_plan_')) {
    const planId = parseInt(data.replace('buy_plan_', ''));
    const plan = planHelpers.getById.get(planId);
    if (!plan) {
      await bot.answerCallbackQuery(query.id, { text: '❌ Тариф не найден' });
      return;
    }

    await bot.answerCallbackQuery(query.id);
    await bot.editMessageText(chatId, msgId,
      `📦 *${plan.name}*\n\nКак хочешь оплатить?`,
      {
        parseMode: 'Markdown',
        replyMarkup: bot.inlineKeyboard([
          [bot.button('inline', `⭐ Telegram Stars (${plan.price_stars}★)`, 'callbackData', `pay_stars_${planId}`)],
          [bot.button('inline', `💳 ЮKassa (${plan.price_rub}₽)`, 'callbackData', `pay_yukassa_${planId}`)],
          [bot.button('inline', `💰 Robokassa (${plan.price_rub}₽)`, 'callbackData', `pay_robokassa_${planId}`)],
          [bot.button('inline', '⬅ Назад', 'callbackData', 'back_to_plans')],
        ])
      }
    );
    return;
  }

  if (data === 'back_to_plans') {
    const plans = planHelpers.getAll.all();
    const buttons = plans.map(p => [
      bot.button('inline', `${p.name} — ${p.price_stars}⭐ / ${p.price_rub}₽`, 'callbackData', `buy_plan_${p.id}`)
    ]);
    buttons.push([bot.button('inline', '❌ Отмена', 'callbackData', 'cancel')]);
    await bot.answerCallbackQuery(query.id);
    await bot.editMessageText(chatId, msgId, `💳 *Выбери тариф:*`, { parseMode: 'Markdown', replyMarkup: bot.inlineKeyboard(buttons) });
    return;
  }

  // ── Оплата через Telegram Stars ──────────────
  if (data.startsWith('pay_stars_')) {
    const planId = parseInt(data.replace('pay_stars_', ''));
    const plan = planHelpers.getById.get(planId);
    if (!plan) return;

    const user = getUserByTgId(tgId);
    if (!user) {
      await bot.answerCallbackQuery(query.id, { text: '❌ Не найден аккаунт' });
      return;
    }

    // Создаём платёж в БД
    const tmpId = `tg_${Date.now()}`;
    const result = paymentHelpers.create.run(user.id, plan.price_stars, 'XTR', 'telegram_stars', plan.days, tmpId);
    const paymentId = result.lastInsertRowid;
    db.prepare('UPDATE payments SET provider_payment_id=? WHERE id=?').run(`pay_${paymentId}_${Date.now()}`, paymentId);

    await bot.answerCallbackQuery(query.id);

    // Отправляем инвойс
    try {
      await bot.sendInvoice(chatId, {
        title: `🔒 ONION VPN — ${plan.name}`,
        description: `PRO подписка на ${plan.days} дней. Все серверы, безлимит.`,
        payload: `payment_${paymentId}`,
        currency: 'XTR',
        prices: [{ label: plan.name, amount: plan.price_stars }],
      });
    } catch (e) {
      console.error('[BOT] Ошибка отправки инвойса:', e.message);
      await bot.sendMessage(chatId, `❌ Не удалось создать инвойс. Попробуй через веб-приложение: ${APP_URL}`);
    }
    return;
  }

  // ── Оплата через ЮKassa/Robokassa ────────────
  if (data.startsWith('pay_yukassa_') || data.startsWith('pay_robokassa_')) {
    const method = data.startsWith('pay_yukassa_') ? 'yukassa' : 'robokassa';
    const planId = parseInt(data.replace(/pay_(yukassa|robokassa)_/, ''));
    const plan = planHelpers.getById.get(planId);
    if (!plan) return;

    const user = getUserByTgId(tgId);
    if (!user) {
      await bot.answerCallbackQuery(query.id, { text: '❌ Не найден аккаунт' });
      return;
    }

    try {
      const resp = await fetch(`${APP_URL}/payment/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-bot-secret': BOT_SECRET },
        body: JSON.stringify({ planId, method, userId: user.id }),
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        await bot.answerCallbackQuery(query.id, { text: err.error || 'Ошибка создания платежа' });
        return;
      }

      const data2 = await resp.json();
      await bot.answerCallbackQuery(query.id);
      await bot.sendMessage(chatId,
        `💳 Переди по ссылке для оплаты *${plan.name}* (${plan.price_rub}₽):`,
        {
          parseMode: 'Markdown',
          replyMarkup: bot.inlineKeyboard([[bot.button('inline', '💳 Оплатить', 'url', data2.redirectUrl)]])
        }
      );
    } catch (e) {
      console.error('[BOT] Ошибка создания платежа:', e);
      await bot.answerCallbackQuery(query.id, { text: '❌ Ошибка сервера' });
    }
    return;
  }
});

// ================================================
// Pre-checkout query (Telegram Stars) — всегда одобряем
// ================================================
bot.on('preCheckoutQuery', async (query) => {
  await bot.answerPreCheckoutQuery(query.id, { ok: true });
});

// ================================================
// Успешная оплата TG Stars
// ================================================
bot.on('successfulPayment', async (msg) => {
  const payment = msg.successful_payment;
  const tgId = msg.from.id;

  console.log(`[BOT] Успешная оплата: payload=${payment.invoice_payload}, charge=${payment.telegram_payment_charge_id}`);

  try {
    const resp = await fetch(`${APP_URL}/payment/confirm-stars`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        paymentPayload: payment.invoice_payload,
        telegramPaymentChargeId: payment.telegram_payment_charge_id,
        secret: BOT_SECRET,
      }),
    });

    const result = await resp.json();
    if (result.ok) {
      await bot.sendMessage(msg.chat.id,
        `✅ *Оплата прошла успешно!*\n\n⭐ Stars получены, подписка активирована!\nДействует до: *${formatDate(result.expiresAt)}*\n\n🎉 Наслаждайся безлимитным VPN!`,
        { parseMode: 'Markdown', replyMarkup: mainKeyboard() }
      );
    } else {
      await bot.sendMessage(msg.chat.id, `⚠️ Оплата получена, но произошла ошибка активации. Свяжись с поддержкой. Charge ID: ${payment.telegram_payment_charge_id}`);
    }
  } catch (e) {
    console.error('[BOT] Ошибка подтверждения Stars:', e);
    await bot.sendMessage(msg.chat.id, `⚠️ Оплата получена, ожидается активация. Charge ID: ${payment.telegram_payment_charge_id}`);
  }
});

// ================================================
// 👥 Пригласить друга
// ================================================
bot.on(/(👥 Пригласить друга|\/refer)/, async (msg) => {
  const user = getUserByTgId(msg.from.id);
  if (!user) return bot.sendMessage(msg.chat.id, '❌ Напиши /start');

  const refCount = referralHelpers.countByReferrer.get(user.id).cnt;
  const refLink = `https://t.me/${process.env.TELEGRAM_BOT_USERNAME}?start=ref_${user.referral_code}`;

  await bot.sendMessage(msg.chat.id,
    `👥 *Реферальная программа*\n\n` +
    `Приглашай друзей и получай *+2 дня PRO* за каждого!\n\n` +
    `🔗 Твоя ссылка:\n\`${refLink}\`\n\n` +
    `👤 Приглашено: *${refCount}* человек\n` +
    `🎁 Бонусов получено: *${refCount * 2}* дней\n\n` +
    `_Бонус начисляется автоматически, когда друг регистрируется по твоей ссылке_`,
    { parseMode: 'Markdown' }
  );
});

// ================================================
// 🌐 Подключиться — открыть веб-приложение
// ================================================
bot.on(/(🌐 Подключиться к VPN|\/connect)/, async (msg) => {
  await bot.sendMessage(msg.chat.id,
    `🌐 Управление VPN доступно через веб-приложение:`,
    {
      replyMarkup: bot.inlineKeyboard([[bot.button('inline', '🚀 Открыть ONION VPN', 'url', APP_URL)]])
    }
  );
});

// ================================================
// ❓ Помощь
// ================================================
bot.on(/(❓ Помощь|\/help)/, async (msg) => {
  await bot.sendMessage(msg.chat.id,
    `❓ *Помощь по ONION VPN*\n\n` +
    `📦 *Планы:*\n` +
    `• 🆓 Free — до 10 GB трафика, базовые серверы\n` +
    `• ⭐ PRO — безлимит, все серверы, быстрые каналы\n\n` +
    `💳 *Оплата:*\n` +
    `• Telegram Stars (⭐)\n` +
    `• ЮKassa (карта, СБП, ЮMoney)\n` +
    `• Robokassa\n\n` +
    `👥 *Рефералы:*\n` +
    `+2 дня PRO за каждого приглашённого друга\n\n` +
    `🌐 Для подключения используй веб-приложение:\n${APP_URL}`,
    { parseMode: 'Markdown' }
  );
});

// ================================================
// ЗАПУСК
// ================================================
bot.start();
console.log(`\n🤖 ONION VPN Bot запущен`);
console.log(`   Bot: @${process.env.TELEGRAM_BOT_USERNAME}`);
console.log(`   APP: ${APP_URL}\n`);
