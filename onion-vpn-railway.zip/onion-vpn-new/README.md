# 🧅 ONION VPN v2.0

VPN-панель с авторизацией через Telegram, подпиской с оплатой и реферальной программой.

---

## 🆕 Что нового в v2.0

- ✅ **Управление серверами** — добавление, редактирование, удаление из админки
- ✅ **Оплата подписки** — Telegram Stars, ЮKassa, Robokassa
- ✅ **Реферальная система** — +2 дня PRO за каждого приглашённого
- ✅ **Гибкие тарифы** — создание любых планов из админки
- ✅ **Telegram-бот** (telebot) — оплата Stars, управление аккаунтом
- ✅ **APK файл** — инструкция и конфиг для сборки Android-приложения
- ✅ **История платежей** — для пользователей и администраторов

---

## 🚀 Быстрый старт

### 1. Установка
```bash
npm install
```

### 2. Настройка .env
```bash
cp .env.example .env
# Отредактируй .env
```

**Обязательные переменные:**
```env
TELEGRAM_BOT_TOKEN=1234567890:ABCdef...
TELEGRAM_BOT_USERNAME=YourBotUsername
SESSION_SECRET=random_32_char_string
BOT_INTERNAL_SECRET=another_random_string
APP_URL=https://yourdomain.com
ADMIN_IDS=123456789
```

### 3. Запуск сервера
```bash
npm start
```

### 4. Запуск бота (в отдельном терминале)
```bash
npm run bot
```

### 5. Запуск всего вместе
```bash
npm run dev:all
```

---

## 💳 Настройка оплаты

### Telegram Stars
Работает автоматически через бота. Не требует дополнительной настройки.

### ЮKassa
1. Зарегистрируйся на yookassa.ru
2. Получи Shop ID и Secret Key
3. Добавь в .env:
   ```
   YUKASSA_SHOP_ID=123456
   YUKASSA_SECRET_KEY=your_secret
   ```
4. Настрой вебхук в личном кабинете ЮKassa: `POST https://yourdomain.com/payment/webhook/yukassa`

### Robokassa
1. Зарегистрируйся на robokassa.ru
2. Получи логин и пароли
3. Добавь в .env:
   ```
   ROBOKASSA_LOGIN=your_login
   ROBOKASSA_PASS1=password1
   ROBOKASSA_PASS2=password2
   ```
4. Настрой вебхук в личном кабинете: `POST https://yourdomain.com/payment/webhook/robokassa`

---

## 👥 Реферальная программа

- Каждый пользователь получает уникальную реф-ссылку
- Ссылка вида: `https://t.me/YourBot?start=ref_ABCD1234`
- При регистрации по ссылке **рефереру начисляется +2 дня PRO**
- Бонусы суммируются: 10 рефералов = +20 дней PRO

---

## 📱 APK файл

Смотри инструкцию в `apk-build/README.md`

Краткая версия:
```bash
cd apk-build
npm install
npx cap add android
npx cap sync android
npx cap open android
# Затем в Android Studio: Build → Build APK
```

---

## 🔑 API эндпоинты

### Авторизация
- `POST /auth/telegram` — вход через Telegram Widget
- `GET /auth/me` — данные текущего пользователя
- `POST /auth/logout` — выход
- `GET /auth/botname` — имя бота для виджета

### VPN
- `GET /vpn/servers` — список серверов
- `POST /vpn/connect` — подключение к серверу
- `POST /vpn/disconnect` — отключение
- `GET /vpn/status` — статус подключения

### Оплата
- `GET /payment/plans` — тарифы
- `POST /payment/create` — создать платёж
- `GET /payment/check/:id` — статус платежа
- `GET /payment/history` — история платежей
- `POST /payment/webhook/yukassa` — вебхук ЮKassa
- `POST /payment/webhook/robokassa` — вебхук Robokassa
- `POST /payment/confirm-stars` — подтверждение TG Stars (внутренний)

### Админка (только для admin)
- `GET /admin/stats` — статистика
- `GET /admin/users` — список пользователей
- `POST /admin/users/:id/ban` — бан
- `POST /admin/users/:id/unban` — разбан
- `POST /admin/users/:id/role` — изменить роль
- `POST /admin/users/:id/grant-days` — выдать дни PRO
- `GET /admin/servers` — список серверов
- `POST /admin/servers/add` — добавить сервер
- `PUT /admin/servers/:id` — изменить сервер
- `DELETE /admin/servers/:id` — удалить сервер
- `POST /admin/servers/:id/toggle` — вкл/выкл сервер
- `GET /admin/plans` — тарифы
- `POST /admin/plans` — добавить тариф
- `PUT /admin/plans/:id` — изменить тариф
- `DELETE /admin/plans/:id` — удалить тариф
- `GET /admin/payments` — все платежи
- `GET /admin/logs` — системные логи
- `GET /admin/traffic` — статистика трафика

---

## 🗂 Структура проекта

```
onion-vpn/
├── server.js              # Express сервер
├── package.json           # Зависимости
├── .env.example           # Пример конфига
├── db/
│   └── database.js        # SQLite БД + хелперы
├── middleware/
│   └── telegramAuth.js    # Проверка TG подписи
├── routes/
│   ├── auth.js            # Авторизация + рефералы
│   ├── vpn.js             # VPN серверы
│   ├── admin.js           # Панель администратора
│   └── payment.js         # Оплата подписки
├── bot/
│   └── bot.js             # Telegram бот (telebot)
├── public/
│   └── index.html         # Фронтенд SPA
├── data/
│   └── onion_vpn.db       # SQLite база данных
└── apk-build/
    ├── README.md           # Инструкция по сборке APK
    ├── capacitor.config.ts # Конфиг Capacitor
    ├── package.json        # Зависимости APK
    └── AndroidManifest.xml # Манифест Android
```
