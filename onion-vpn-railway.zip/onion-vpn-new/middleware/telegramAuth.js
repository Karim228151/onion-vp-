// middleware/telegramAuth.js
// Проверка подписи данных от Telegram Login Widget
const crypto = require('crypto');

/**
 * Верифицирует данные от Telegram Login Widget
 * Алгоритм: https://core.telegram.org/widgets/login#checking-authorization
 */
function verifyTelegramAuth(data, botToken) {
  const { hash, ...authData } = data;
  
  if (!hash) return false;
  
  // Проверяем время (данные действительны 24 часа)
  const authDate = parseInt(authData.auth_date);
  const currentTime = Math.floor(Date.now() / 1000);
  if (currentTime - authDate > 86400) {
    return false; // Данные устарели
  }
  
  // Создаём строку для проверки
  const dataCheckString = Object.keys(authData)
    .sort()
    .map(key => `${key}=${authData[key]}`)
    .join('\n');
  
  // Создаём секретный ключ из токена бота
  const secretKey = crypto
    .createHash('sha256')
    .update(botToken)
    .digest();
  
  // Вычисляем HMAC
  const computedHash = crypto
    .createHmac('sha256', secretKey)
    .update(dataCheckString)
    .digest('hex');
  
  return computedHash === hash;
}

/**
 * Middleware для проверки авторизации через Telegram
 */
function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ error: 'Требуется авторизация' });
  }
  next();
}

/**
 * Middleware для проверки прав администратора
 */
function requireAdmin(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ error: 'Требуется авторизация' });
  }
  if (req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Доступ запрещён. Требуются права администратора.' });
  }
  next();
}

module.exports = { verifyTelegramAuth, requireAuth, requireAdmin };
