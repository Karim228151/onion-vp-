// db/database.js - SQLite база данных ONION VPN v2
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '../data/onion_vpn.db');
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER UNIQUE NOT NULL,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    photo_url TEXT,
    role TEXT DEFAULT 'user' CHECK(role IN ('user', 'admin')),
    plan TEXT DEFAULT 'free' CHECK(plan IN ('free', 'pro')),
    plan_expires_at DATETIME,
    traffic_used INTEGER DEFAULT 0,
    traffic_limit INTEGER DEFAULT 10737418240,
    is_banned INTEGER DEFAULT 0,
    ban_reason TEXT,
    referral_code TEXT UNIQUE,
    referred_by INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
    auth_hash TEXT,
    FOREIGN KEY (referred_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS vpn_servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    country TEXT NOT NULL,
    flag TEXT NOT NULL,
    ip TEXT NOT NULL,
    port INTEGER DEFAULT 51820,
    protocol TEXT DEFAULT 'WireGuard',
    load_percent INTEGER DEFAULT 0,
    online_users INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    is_premium INTEGER DEFAULT 0,
    ping_ms INTEGER DEFAULT 50,
    wg_public_key TEXT,
    wg_private_key TEXT,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS connections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    server_id INTEGER NOT NULL,
    connected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    disconnected_at DATETIME,
    traffic_bytes INTEGER DEFAULT 0,
    client_ip TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (server_id) REFERENCES vpn_servers(id)
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount INTEGER NOT NULL,
    currency TEXT DEFAULT 'RUB',
    method TEXT NOT NULL CHECK(method IN ('telegram_stars', 'yukassa', 'robokassa')),
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'paid', 'failed', 'refunded')),
    days_granted INTEGER NOT NULL,
    plan TEXT DEFAULT 'pro',
    provider_payment_id TEXT,
    provider_data TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    paid_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS subscription_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    days INTEGER NOT NULL,
    price_rub INTEGER NOT NULL,
    price_stars INTEGER NOT NULL,
    is_active INTEGER DEFAULT 1,
    sort_order INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS referrals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    referrer_id INTEGER NOT NULL,
    referred_id INTEGER NOT NULL,
    bonus_days INTEGER DEFAULT 2,
    activated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (referrer_id) REFERENCES users(id),
    FOREIGN KEY (referred_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS system_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level TEXT DEFAULT 'info' CHECK(level IN ('info', 'warn', 'error', 'auth', 'payment')),
    message TEXT NOT NULL,
    user_id INTEGER,
    ip TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Начальные данные
const serversCount = db.prepare('SELECT COUNT(*) as cnt FROM vpn_servers').get();
if (serversCount.cnt === 0) {
  const ins = db.prepare(`INSERT INTO vpn_servers (name, country, flag, ip, ping_ms, is_premium, load_percent, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
  [
    ['DE-01', 'Германия', '🇩🇪', '185.220.101.45', 32, 0, 42, 'Быстрый европейский сервер'],
    ['NL-01', 'Нидерланды', '🇳🇱', '193.111.14.72', 28, 0, 67, 'Лучший для стриминга'],
    ['FI-01', 'Финляндия', '🇫🇮', '37.120.198.44', 45, 0, 15, 'Минимальные логи'],
    ['US-01', 'США', '🇺🇸', '104.21.18.99', 110, 1, 21, 'Доступ к US-контенту'],
    ['JP-01', 'Япония', '🇯🇵', '45.76.120.33', 180, 1, 33, 'Аниме и JP-сервисы'],
    ['SG-01', 'Сингапур', '🇸🇬', '139.99.91.115', 155, 1, 18, 'Быстрый Азия-сервер'],
  ].forEach(s => ins.run(...s));
}

const plansCount = db.prepare('SELECT COUNT(*) as cnt FROM subscription_plans').get();
if (plansCount.cnt === 0) {
  const ins = db.prepare(`INSERT INTO subscription_plans (name, days, price_rub, price_stars, sort_order) VALUES (?, ?, ?, ?, ?)`);
  [
    ['7 дней', 7, 149, 50, 1],
    ['30 дней', 30, 399, 150, 2],
    ['90 дней', 90, 999, 400, 3],
    ['365 дней', 365, 2999, 1200, 4],
  ].forEach(p => ins.run(...p));
}

// ================================================
// ХЕЛПЕРЫ
// ================================================
const userHelpers = {
  findByTelegramId: db.prepare('SELECT * FROM users WHERE telegram_id = ?'),
  create: db.prepare(`INSERT INTO users (telegram_id, username, first_name, last_name, photo_url, role, auth_hash, referral_code, referred_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`),
  update: db.prepare(`UPDATE users SET username=?, first_name=?, last_name=?, photo_url=?, last_seen=CURRENT_TIMESTAMP, auth_hash=? WHERE telegram_id=?`),
  updateLastSeen: db.prepare('UPDATE users SET last_seen=CURRENT_TIMESTAMP WHERE id=?'),
  getAll: db.prepare('SELECT * FROM users ORDER BY created_at DESC'),
  getById: db.prepare('SELECT * FROM users WHERE id=?'),
  ban: db.prepare('UPDATE users SET is_banned=1, ban_reason=? WHERE id=?'),
  unban: db.prepare('UPDATE users SET is_banned=0, ban_reason=NULL WHERE id=?'),
  setRole: db.prepare('UPDATE users SET role=? WHERE id=?'),
  count: db.prepare('SELECT COUNT(*) as cnt FROM users'),
  countOnline: db.prepare(`SELECT COUNT(*) as cnt FROM users WHERE last_seen > datetime('now', '-5 minutes')`),
  addTraffic: db.prepare('UPDATE users SET traffic_used = traffic_used + ? WHERE id=?'),
  findByReferralCode: db.prepare('SELECT * FROM users WHERE referral_code = ?'),
  extendPlan(userId, days) {
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
    const now = new Date();
    let exp = (user.plan_expires_at && new Date(user.plan_expires_at) > now)
      ? new Date(user.plan_expires_at) : new Date(now);
    exp.setDate(exp.getDate() + days);
    db.prepare('UPDATE users SET plan=?, traffic_limit=?, plan_expires_at=? WHERE id=?')
      .run('pro', 1099511627776, exp.toISOString(), userId);
    return exp;
  },
  checkExpiry(userId) {
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
    if (user.plan === 'pro' && user.plan_expires_at && new Date(user.plan_expires_at) < new Date()) {
      db.prepare('UPDATE users SET plan=?, traffic_limit=? WHERE id=?').run('free', 10737418240, userId);
    }
  },
};

const serverHelpers = {
  getAll: db.prepare('SELECT * FROM vpn_servers ORDER BY is_premium ASC, ping_ms ASC'),
  getById: db.prepare('SELECT * FROM vpn_servers WHERE id=?'),
  getActive: db.prepare('SELECT * FROM vpn_servers WHERE is_active=1 ORDER BY is_premium ASC, ping_ms ASC'),
  updateLoad: db.prepare('UPDATE vpn_servers SET load_percent=?, online_users=? WHERE id=?'),
  toggle: db.prepare('UPDATE vpn_servers SET is_active=? WHERE id=?'),
  add: db.prepare(`INSERT INTO vpn_servers (name, country, flag, ip, port, protocol, ping_ms, is_premium, wg_public_key, wg_private_key, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`),
  update: db.prepare(`UPDATE vpn_servers SET name=?, country=?, flag=?, ip=?, port=?, protocol=?, ping_ms=?, is_premium=?, wg_public_key=?, wg_private_key=?, description=? WHERE id=?`),
  delete: db.prepare('DELETE FROM vpn_servers WHERE id=?'),
};

const logHelpers = {
  add: db.prepare('INSERT INTO system_logs (level, message, user_id, ip) VALUES (?, ?, ?, ?)'),
  getRecent: db.prepare('SELECT l.*, u.username FROM system_logs l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC LIMIT 200'),
};

const connectionHelpers = {
  start: db.prepare('INSERT INTO connections (user_id, server_id, client_ip) VALUES (?, ?, ?)'),
  end: db.prepare('UPDATE connections SET disconnected_at=CURRENT_TIMESTAMP, traffic_bytes=? WHERE user_id=? AND disconnected_at IS NULL'),
  getActive: db.prepare('SELECT COUNT(*) as cnt FROM connections WHERE disconnected_at IS NULL'),
};

const paymentHelpers = {
  create: db.prepare(`INSERT INTO payments (user_id, amount, currency, method, days_granted, provider_payment_id) VALUES (?, ?, ?, ?, ?, ?)`),
  getById: db.prepare('SELECT * FROM payments WHERE id=?'),
  getByProviderId: db.prepare('SELECT * FROM payments WHERE provider_payment_id=?'),
  confirm: db.prepare(`UPDATE payments SET status='paid', paid_at=CURRENT_TIMESTAMP, provider_data=? WHERE id=?`),
  fail: db.prepare(`UPDATE payments SET status='failed' WHERE id=?`),
  getByUser: db.prepare('SELECT * FROM payments WHERE user_id=? ORDER BY created_at DESC'),
  getAll: db.prepare('SELECT p.*, u.username, u.first_name FROM payments p JOIN users u ON p.user_id=u.id ORDER BY p.created_at DESC LIMIT 100'),
};

const planHelpers = {
  getAll: db.prepare('SELECT * FROM subscription_plans WHERE is_active=1 ORDER BY sort_order'),
  getAllAdmin: db.prepare('SELECT * FROM subscription_plans ORDER BY sort_order'),
  getById: db.prepare('SELECT * FROM subscription_plans WHERE id=?'),
  add: db.prepare('INSERT INTO subscription_plans (name, days, price_rub, price_stars, sort_order) VALUES (?, ?, ?, ?, ?)'),
  update: db.prepare('UPDATE subscription_plans SET name=?, days=?, price_rub=?, price_stars=?, is_active=? WHERE id=?'),
  delete: db.prepare('DELETE FROM subscription_plans WHERE id=?'),
};

const referralHelpers = {
  create: db.prepare('INSERT INTO referrals (referrer_id, referred_id, bonus_days) VALUES (?, ?, 2)'),
  countByReferrer: db.prepare('SELECT COUNT(*) as cnt FROM referrals WHERE referrer_id=?'),
  getByReferrer: db.prepare('SELECT r.*, u.username, u.first_name FROM referrals r JOIN users u ON r.referred_id=u.id WHERE r.referrer_id=? ORDER BY r.activated_at DESC'),
};

module.exports = { db, userHelpers, serverHelpers, logHelpers, connectionHelpers, paymentHelpers, planHelpers, referralHelpers };
