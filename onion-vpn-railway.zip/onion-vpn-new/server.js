// server.js - ONION VPN v2
require('dotenv').config();

const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Railway автоматически даёт публичный домен в RAILWAY_PUBLIC_DOMAIN
const APP_URL = process.env.APP_URL ||
  (process.env.RAILWAY_PUBLIC_DOMAIN ? `https://${process.env.RAILWAY_PUBLIC_DOMAIN}` : `http://localhost:${PORT}`);

// Сохраняем APP_URL чтобы бот мог использовать
process.env.APP_URL = APP_URL;

if (!process.env.TELEGRAM_BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN === 'YOUR_BOT_TOKEN_HERE') {
  console.error('\n❌ Не указан TELEGRAM_BOT_TOKEN\n');
  process.exit(1);
}
if (!process.env.TELEGRAM_BOT_USERNAME || process.env.TELEGRAM_BOT_USERNAME === 'YOUR_BOT_USERNAME_HERE') {
  console.error('\n❌ Не указан TELEGRAM_BOT_USERNAME\n');
  process.exit(1);
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: true, credentials: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'onion-vpn-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: APP_URL.startsWith('https'),
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000,
    sameSite: APP_URL.startsWith('https') ? 'none' : 'lax',
  },
  name: 'onion.sid',
}));

app.use(express.static(path.join(__dirname, 'public')));

app.use('/auth', require('./routes/auth'));
app.use('/vpn',  require('./routes/vpn'));
app.use('/admin', require('./routes/admin'));
app.use('/payment', require('./routes/payment'));

app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString(), url: APP_URL }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((err, req, res, next) => {
  console.error('[ERROR]', err);
  res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🧅 ONION VPN v2 запущен`);
  console.log(`   URL: ${APP_URL}`);
  console.log(`   PORT: ${PORT}`);
  console.log(`   Bot: @${process.env.TELEGRAM_BOT_USERNAME}`);
  console.log(`   Режим: ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app;
