// routes/vpn.js - VPN серверы и подключения
const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/telegramAuth');
const { serverHelpers, connectionHelpers, userHelpers, logHelpers } = require('../db/database');

router.get('/servers', requireAuth, (req, res) => {
  userHelpers.checkExpiry(req.session.userId);
  const user = userHelpers.getById.get(req.session.userId);
  const servers = serverHelpers.getActive.all();
  const result = servers.map(s => ({ ...s, locked: s.is_premium && user.plan === 'free' }));
  res.json({ servers: result, userPlan: user.plan, planExpiresAt: user.plan_expires_at });
});

router.post('/connect', requireAuth, (req, res) => {
  const { serverId } = req.body;
  userHelpers.checkExpiry(req.session.userId);
  const user = userHelpers.getById.get(req.session.userId);
  if (!serverId) return res.status(400).json({ error: 'Укажи сервер' });
  const server = serverHelpers.getById.get(serverId);
  if (!server) return res.status(404).json({ error: 'Сервер не найден' });
  if (!server.is_active) return res.status(400).json({ error: 'Сервер недоступен' });
  if (server.is_premium && user.plan === 'free') return res.status(403).json({ error: 'Этот сервер доступен только на плане PRO', needUpgrade: true });
  if (user.traffic_used >= user.traffic_limit) return res.status(403).json({ error: 'Лимит трафика исчерпан', needUpgrade: true });

  connectionHelpers.end.run(0, user.id);
  connectionHelpers.start.run(user.id, serverId, req.ip);
  serverHelpers.updateLoad.run(Math.min(99, server.load_percent + 1), server.online_users + 1, serverId);
  logHelpers.add.run('info', `Подключение: @${user.username || user.first_name} → ${server.name}`, user.id, req.ip);

  const vpnConfig = generateVPNConfig(user, server);
  res.json({ success: true, connection: { serverName: server.name, serverIp: server.ip, country: server.country, flag: server.flag, protocol: server.protocol, ping: server.ping_ms, vpnConfig } });
});

router.post('/disconnect', requireAuth, (req, res) => {
  const user = userHelpers.getById.get(req.session.userId);
  const trafficBytes = req.body.trafficBytes || 0;
  connectionHelpers.end.run(trafficBytes, user.id);
  if (trafficBytes > 0) userHelpers.addTraffic.run(trafficBytes, user.id);
  logHelpers.add.run('info', `Отключение: @${user.username || user.first_name}`, user.id, req.ip);
  res.json({ success: true });
});

router.get('/status', requireAuth, (req, res) => {
  userHelpers.checkExpiry(req.session.userId);
  const user = userHelpers.getById.get(req.session.userId);
  res.json({ trafficUsed: user.traffic_used, trafficLimit: user.traffic_limit, plan: user.plan, planExpiresAt: user.plan_expires_at });
});

function generateVPNConfig(user, server) {
  const clientPrivKey = generateKey();
  const serverPubKey = server.wg_public_key || generateKey();
  return `[Interface]
# ONION VPN - ${server.name}
PrivateKey = ${clientPrivKey}
Address = 10.8.${Math.floor(user.id / 256)}.${user.id % 256}/32
DNS = 1.1.1.1, 1.0.0.1

[Peer]
PublicKey = ${serverPubKey}
Endpoint = ${server.ip}:${server.port}
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25`;
}

function generateKey() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let k = '';
  for (let i = 0; i < 43; i++) k += chars[Math.floor(Math.random() * chars.length)];
  return k + '=';
}

module.exports = router;
