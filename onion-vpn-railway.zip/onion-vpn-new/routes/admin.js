// routes/admin.js - Панель администратора v2
const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/telegramAuth');
const { userHelpers, serverHelpers, logHelpers, connectionHelpers, paymentHelpers, planHelpers, db } = require('../db/database');

router.use(requireAdmin);

// ── Статистика ──────────────────────────────────
router.get('/stats', (req, res) => {
  const totalUsers = userHelpers.count.get().cnt;
  const onlineUsers = userHelpers.countOnline.get().cnt;
  const activeConnections = connectionHelpers.getActive.get().cnt;
  const allServers = serverHelpers.getAll.all();
  const activeServers = allServers.filter(s => s.is_active).length;
  const trafficResult = db.prepare(`SELECT COALESCE(SUM(traffic_bytes),0) as total FROM connections WHERE connected_at > datetime('now','-30 days')`).get();
  const newToday = db.prepare(`SELECT COUNT(*) as cnt FROM users WHERE created_at > datetime('now','-24 hours')`).get().cnt;
  const plans = db.prepare('SELECT plan, COUNT(*) as cnt FROM users GROUP BY plan').all();
  const revenueResult = db.prepare(`SELECT COALESCE(SUM(amount),0) as total FROM payments WHERE status='paid' AND currency='RUB'`).get();
  const revenueMonth = db.prepare(`SELECT COALESCE(SUM(amount),0) as total FROM payments WHERE status='paid' AND currency='RUB' AND paid_at > datetime('now','-30 days')`).get();
  res.json({ totalUsers, onlineUsers, activeConnections, activeServers, totalServers: allServers.length, trafficMonth: trafficResult.total, newToday, plans, revenueTotal: revenueResult.total, revenueMonth: revenueMonth.total });
});

// ── Пользователи ────────────────────────────────
router.get('/users', (req, res) => {
  const { search, filter } = req.query;
  let query = 'SELECT * FROM users';
  const params = [];
  if (search) {
    query += ' WHERE (username LIKE ? OR first_name LIKE ? OR CAST(telegram_id AS TEXT) LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s, s);
  }
  if (filter === 'online') query += (params.length ? ' AND' : ' WHERE') + ` last_seen > datetime('now','-5 minutes')`;
  else if (filter === 'banned') query += (params.length ? ' AND' : ' WHERE') + ' is_banned=1';
  else if (filter === 'pro') query += (params.length ? ' AND' : ' WHERE') + " plan='pro'";
  query += ' ORDER BY created_at DESC';
  res.json({ users: db.prepare(query).all(...params) });
});

router.post('/users/:id/ban', (req, res) => {
  const userId = parseInt(req.params.id);
  if (userId === req.session.userId) return res.status(400).json({ error: 'Нельзя забанить себя' });
  const target = userHelpers.getById.get(userId);
  if (!target) return res.status(404).json({ error: 'Не найден' });
  userHelpers.ban.run(req.body.reason || 'Нарушение правил', userId);
  logHelpers.add.run('warn', `БАН: @${target.username || target.first_name} — ${req.body.reason || 'без причины'}`, req.session.userId, req.ip);
  res.json({ success: true });
});

router.post('/users/:id/unban', (req, res) => {
  const userId = parseInt(req.params.id);
  const target = userHelpers.getById.get(userId);
  if (!target) return res.status(404).json({ error: 'Не найден' });
  userHelpers.unban.run(userId);
  logHelpers.add.run('info', `РАЗБАН: @${target.username || target.first_name}`, req.session.userId, req.ip);
  res.json({ success: true });
});

router.post('/users/:id/role', (req, res) => {
  const { role } = req.body;
  const userId = parseInt(req.params.id);
  if (!['user', 'admin'].includes(role)) return res.status(400).json({ error: 'Неверная роль' });
  if (userId === req.session.userId) return res.status(400).json({ error: 'Нельзя изменить свою роль' });
  const target = userHelpers.getById.get(userId);
  if (!target) return res.status(404).json({ error: 'Не найден' });
  userHelpers.setRole.run(role, userId);
  logHelpers.add.run('info', `РОЛЬ: @${target.username || target.first_name} → ${role}`, req.session.userId, req.ip);
  res.json({ success: true });
});

router.post('/users/:id/grant-days', (req, res) => {
  const { days } = req.body;
  const userId = parseInt(req.params.id);
  if (!days || days < 1) return res.status(400).json({ error: 'Укажи количество дней' });
  const target = userHelpers.getById.get(userId);
  if (!target) return res.status(404).json({ error: 'Не найден' });
  const exp = userHelpers.extendPlan(userId, parseInt(days));
  logHelpers.add.run('info', `ПОДАРОК: @${target.username || target.first_name} +${days}д PRO → ${exp.toISOString()}`, req.session.userId, req.ip);
  res.json({ success: true, expiresAt: exp });
});

// ── Серверы ─────────────────────────────────────
router.get('/servers', (req, res) => res.json({ servers: serverHelpers.getAll.all() }));

router.post('/servers/add', (req, res) => {
  const { name, country, flag, ip, port, protocol, ping_ms, is_premium, wg_public_key, wg_private_key, description } = req.body;
  if (!name || !country || !ip) return res.status(400).json({ error: 'Обязательные поля: name, country, ip' });
  const result = serverHelpers.add.run(name, country, flag || '🌐', ip, port || 51820, protocol || 'WireGuard', ping_ms || 50, is_premium ? 1 : 0, wg_public_key || null, wg_private_key || null, description || null);
  logHelpers.add.run('info', `НОВЫЙ СЕРВЕР: ${name} (${ip}) | ${country}`, req.session.userId, req.ip);
  res.json({ success: true, id: result.lastInsertRowid });
});

router.put('/servers/:id', (req, res) => {
  const serverId = parseInt(req.params.id);
  const server = serverHelpers.getById.get(serverId);
  if (!server) return res.status(404).json({ error: 'Не найден' });
  const { name, country, flag, ip, port, protocol, ping_ms, is_premium, wg_public_key, wg_private_key, description } = req.body;
  serverHelpers.update.run(
    name ?? server.name, country ?? server.country, flag ?? server.flag,
    ip ?? server.ip, port ?? server.port, protocol ?? server.protocol,
    ping_ms ?? server.ping_ms, is_premium !== undefined ? (is_premium ? 1 : 0) : server.is_premium,
    wg_public_key ?? server.wg_public_key, wg_private_key ?? server.wg_private_key,
    description ?? server.description, serverId
  );
  logHelpers.add.run('info', `ИЗМЕНЁН СЕРВЕР: ${server.name}`, req.session.userId, req.ip);
  res.json({ success: true });
});

router.delete('/servers/:id', (req, res) => {
  const serverId = parseInt(req.params.id);
  const server = serverHelpers.getById.get(serverId);
  if (!server) return res.status(404).json({ error: 'Не найден' });
  serverHelpers.delete.run(serverId);
  logHelpers.add.run('warn', `УДАЛЁН СЕРВЕР: ${server.name} (${server.ip})`, req.session.userId, req.ip);
  res.json({ success: true });
});

router.post('/servers/:id/toggle', (req, res) => {
  const serverId = parseInt(req.params.id);
  const server = serverHelpers.getById.get(serverId);
  if (!server) return res.status(404).json({ error: 'Не найден' });
  const newState = server.is_active ? 0 : 1;
  serverHelpers.toggle.run(newState, serverId);
  logHelpers.add.run('info', `СЕРВЕР: ${server.name} → ${newState ? 'ОНЛАЙН' : 'ОФЛАЙН'}`, req.session.userId, req.ip);
  res.json({ success: true, isActive: newState });
});

// ── Планы подписки ──────────────────────────────
router.get('/plans', (req, res) => res.json({ plans: planHelpers.getAllAdmin.all() }));

router.post('/plans', (req, res) => {
  const { name, days, price_rub, price_stars, sort_order } = req.body;
  if (!name || !days || !price_rub || !price_stars) return res.status(400).json({ error: 'Заполни все поля' });
  const result = planHelpers.add.run(name, days, price_rub, price_stars, sort_order || 99);
  logHelpers.add.run('info', `НОВЫЙ ПЛАН: ${name} (${days}д, ${price_rub}₽)`, req.session.userId, req.ip);
  res.json({ success: true, id: result.lastInsertRowid });
});

router.put('/plans/:id', (req, res) => {
  const planId = parseInt(req.params.id);
  const { name, days, price_rub, price_stars, is_active } = req.body;
  planHelpers.update.run(name, days, price_rub, price_stars, is_active !== undefined ? is_active : 1, planId);
  res.json({ success: true });
});

router.delete('/plans/:id', (req, res) => {
  planHelpers.delete.run(parseInt(req.params.id));
  res.json({ success: true });
});

// ── Платежи ─────────────────────────────────────
router.get('/payments', (req, res) => res.json({ payments: paymentHelpers.getAll.all() }));

// ── Логи ────────────────────────────────────────
router.get('/logs', (req, res) => res.json({ logs: logHelpers.getRecent.all() }));

router.get('/traffic', (req, res) => {
  const daily = db.prepare(`SELECT DATE(connected_at) as day, SUM(traffic_bytes) as bytes, COUNT(*) as sessions FROM connections WHERE connected_at > datetime('now','-7 days') GROUP BY DATE(connected_at) ORDER BY day ASC`).all();
  const byServer = db.prepare(`SELECT s.name, s.country, s.flag, SUM(c.traffic_bytes) as bytes FROM connections c JOIN vpn_servers s ON c.server_id=s.id GROUP BY s.id ORDER BY bytes DESC`).all();
  res.json({ daily, byServer });
});

module.exports = router;
