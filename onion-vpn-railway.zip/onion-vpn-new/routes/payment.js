// routes/payment.js - Оплата подписки
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { requireAuth } = require('../middleware/telegramAuth');
const { paymentHelpers, planHelpers, userHelpers, logHelpers } = require('../db/database');

// ================================================
// GET /payment/plans - Планы подписки
// ================================================
router.get('/plans', requireAuth, (req, res) => {
  const plans = planHelpers.getAll.all();
  res.json({ plans });
});

// ================================================
// POST /payment/create - Создать платёж
// Метод: telegram_stars | yukassa | robokassa
// ================================================
router.post('/create', requireAuth, (req, res) => {
  const { planId, method } = req.body;
  const userId = req.session.userId;

  if (!planId || !method) return res.status(400).json({ error: 'Укажи planId и method' });
  if (!['telegram_stars', 'yukassa', 'robokassa'].includes(method)) {
    return res.status(400).json({ error: 'Неверный метод оплаты' });
  }

  const plan = planHelpers.getById.get(planId);
  if (!plan) return res.status(404).json({ error: 'Тариф не найден' });

  const user = userHelpers.getById.get(userId);

  const amount = method === 'telegram_stars' ? plan.price_stars : plan.price_rub;
  const currency = method === 'telegram_stars' ? 'XTR' : 'RUB';

  const tmpId = `pending_${Date.now()}_${userId}`;
  const result = paymentHelpers.create.run(userId, amount, currency, method, plan.days, tmpId);
  const paymentId = result.lastInsertRowid;

  // Обновляем provider_payment_id нормальным значением
  const providerPaymentId = `pay_${paymentId}_${Date.now()}`;
  require('../db/database').db.prepare('UPDATE payments SET provider_payment_id=? WHERE id=?')
    .run(providerPaymentId, paymentId);

  logHelpers.add.run('payment', `Создан платёж #${paymentId} (${method}, ${amount} ${currency}, ${plan.days}д) | @${user.username || user.first_name}`, userId, req.ip);

  if (method === 'telegram_stars') {
    // Ответ для бота: бот должен отправить invoice в телеграм
    return res.json({
      success: true,
      paymentId,
      method: 'telegram_stars',
      invoiceData: {
        title: `🔒 ONION VPN — ${plan.name}`,
        description: `PRO подписка на ${plan.days} дней. Безлимитный трафик, все серверы.`,
        payload: `payment_${paymentId}`,
        currency: 'XTR',
        prices: [{ label: plan.name, amount: plan.price_stars }],
      },
      checkUrl: `/payment/check/${paymentId}`,
    });
  }

  if (method === 'yukassa') {
    const shopId = process.env.YUKASSA_SHOP_ID;
    const secretKey = process.env.YUKASSA_SECRET_KEY;
    if (!shopId || !secretKey) {
      return res.status(503).json({ error: 'ЮKassa не настроена. Укажи YUKASSA_SHOP_ID и YUKASSA_SECRET_KEY в .env' });
    }

    // Формируем данные для ЮKassa
    const idempotenceKey = `${paymentId}-${Date.now()}`;
    const paymentData = {
      amount: { value: (plan.price_rub / 100).toFixed(2), currency: 'RUB' },
      confirmation: {
        type: 'redirect',
        return_url: `${process.env.APP_URL}/payment/success?id=${paymentId}`,
      },
      description: `ONION VPN PRO ${plan.name}`,
      metadata: { paymentId, userId, planId },
      capture: true,
    };

    const credentials = Buffer.from(`${shopId}:${secretKey}`).toString('base64');

    // В реальном проекте — реальный fetch к api.yookassa.ru
    // Здесь возвращаем инструкцию
    return res.json({
      success: true,
      paymentId,
      method: 'yukassa',
      amount: plan.price_rub,
      currency: 'RUB',
      // В боевом режиме здесь будет redirect_url от ЮKassa
      redirectUrl: `${process.env.APP_URL}/payment/yukassa-form?id=${paymentId}&amount=${plan.price_rub}&days=${plan.days}`,
      checkUrl: `/payment/check/${paymentId}`,
    });
  }

  if (method === 'robokassa') {
    const shopLogin = process.env.ROBOKASSA_LOGIN;
    const pass1 = process.env.ROBOKASSA_PASS1;
    if (!shopLogin || !pass1) {
      return res.status(503).json({ error: 'Robokassa не настроена. Укажи ROBOKASSA_LOGIN и ROBOKASSA_PASS1 в .env' });
    }

    const outSum = (plan.price_rub / 100).toFixed(2);
    const invId = paymentId;
    const sig = crypto.createHash('md5').update(`${shopLogin}:${outSum}:${invId}:${pass1}`).digest('hex');
    const redirectUrl = `https://auth.robokassa.ru/Merchant/Index.aspx?MrchLogin=${shopLogin}&OutSum=${outSum}&InvId=${invId}&SignatureValue=${sig}&IsTest=${process.env.NODE_ENV !== 'production' ? 1 : 0}`;

    return res.json({
      success: true,
      paymentId,
      method: 'robokassa',
      redirectUrl,
      checkUrl: `/payment/check/${paymentId}`,
    });
  }
});

// ================================================
// GET /payment/check/:id - Проверка статуса
// ================================================
router.get('/check/:id', requireAuth, (req, res) => {
  const payment = paymentHelpers.getById.get(parseInt(req.params.id));
  if (!payment) return res.status(404).json({ error: 'Платёж не найден' });
  if (payment.user_id !== req.session.userId && req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Нет доступа' });
  }
  res.json({ payment });
});

// ================================================
// GET /payment/history - История платежей
// ================================================
router.get('/history', requireAuth, (req, res) => {
  const payments = paymentHelpers.getByUser.all(req.session.userId);
  res.json({ payments });
});

// ================================================
// POST /payment/webhook/yukassa - Вебхук ЮKassa
// ================================================
router.post('/webhook/yukassa', express.raw({ type: 'application/json' }), (req, res) => {
  try {
    const body = JSON.parse(req.body.toString());
    if (body.event === 'payment.succeeded') {
      const meta = body.object?.metadata;
      if (meta?.paymentId) {
        const payment = paymentHelpers.getById.get(parseInt(meta.paymentId));
        if (payment && payment.status === 'pending') {
          paymentHelpers.confirm.run(JSON.stringify(body.object), payment.id);
          userHelpers.extendPlan(payment.user_id, payment.days_granted);
          logHelpers.add.run('payment', `✅ ЮKassa оплата #${payment.id} (${payment.days_granted}д) подтверждена`, payment.user_id, null);
        }
      }
    }
    res.json({ ok: true });
  } catch (e) {
    console.error('[YUKASSA WEBHOOK]', e);
    res.status(400).json({ error: 'Bad request' });
  }
});

// ================================================
// POST /payment/webhook/robokassa - Вебхук Robokassa
// ================================================
router.post('/webhook/robokassa', (req, res) => {
  try {
    const { OutSum, InvId, SignatureValue } = req.body;
    const pass2 = process.env.ROBOKASSA_PASS2;
    const expectedSig = crypto.createHash('md5').update(`${OutSum}:${InvId}:${pass2}`).digest('hex').toUpperCase();

    if (expectedSig !== SignatureValue?.toUpperCase()) {
      return res.status(400).send('bad signature');
    }

    const payment = paymentHelpers.getById.get(parseInt(InvId));
    if (payment && payment.status === 'pending') {
      paymentHelpers.confirm.run(JSON.stringify(req.body), payment.id);
      userHelpers.extendPlan(payment.user_id, payment.days_granted);
      logHelpers.add.run('payment', `✅ Robokassa оплата #${payment.id} (${payment.days_granted}д) подтверждена`, payment.user_id, null);
    }
    res.send(`OK${InvId}`);
  } catch (e) {
    console.error('[ROBOKASSA WEBHOOK]', e);
    res.status(400).send('error');
  }
});

// ================================================
// POST /payment/confirm-stars - Подтверждение TG Stars из бота
// ================================================
router.post('/confirm-stars', (req, res) => {
  const { paymentPayload, telegramPaymentChargeId, secret } = req.body;

  // Проверяем внутренний секрет (бот использует его для подтверждения)
  if (secret !== process.env.BOT_INTERNAL_SECRET) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  // payload = "payment_123"
  const paymentId = parseInt(paymentPayload?.replace('payment_', ''));
  if (!paymentId) return res.status(400).json({ error: 'Неверный payload' });

  const payment = paymentHelpers.getById.get(paymentId);
  if (!payment) return res.status(404).json({ error: 'Платёж не найден' });
  if (payment.status !== 'pending') return res.json({ ok: true, alreadyProcessed: true });

  paymentHelpers.confirm.run(telegramPaymentChargeId, paymentId);
  const expiresAt = userHelpers.extendPlan(payment.user_id, payment.days_granted);
  logHelpers.add.run('payment', `✅ TG Stars оплата #${paymentId} (${payment.days_granted}д) подтверждена`, payment.user_id, null);

  res.json({ ok: true, expiresAt });
});

module.exports = router;
