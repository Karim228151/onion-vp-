// routes/auth.js - Авторизация + рефералы
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { verifyTelegramAuth } = require('../middleware/telegramAuth');
const { userHelpers, logHelpers, referralHelpers } = require('../db/database');

function generateReferralCode(telegramId) {
  return crypto.createHash('md5').update(String(telegramId) + 'onionvpn').digest('hex').slice(0, 8).toUpperCase();
}

// ── GET /auth/botname ────────────────────────────
router.get('/botname', (req, res) => {
  res.json({ botUsername: process.env.TELEGRAM_BOT_USERNAME || '' });
});

// ── POST /auth/telegram ──────────────────────────
router.post('/telegram', (req, res) => {
  const authData = req.body;

  if (!verifyTelegramAuth(authData, process.env.TELEGRAM_BOT_TOKEN)) {
    logHelpers.add.run('auth', `Неверная подпись от TG ID:${authData.id}`, null, req.ip);
    return res.status(401).json({ error: 'Недействительные данные Telegram' });
  }

  let user = userHelpers.findByTelegramId.get(authData.id);
  const adminIds = (process.env.ADMIN_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
  const hash = crypto.createHash('sha256').update(JSON.stringify(authData)).digest('hex');

  const isFirstUser = userHelpers.count.get().cnt === 0;
  const isAdminId = adminIds.includes(String(authData.id));
  const role = (isFirstUser || isAdminId) ? 'admin' : 'user';

  let isNewUser = false;
  if (!user) {
    isNewUser = true;
    const refCode = generateReferralCode(authData.id);

    // Проверяем реферальный код из query (если пришёл через реферальную ссылку)
    let referredBy = null;
    const refFromQuery = req.body.ref;
    if (refFromQuery) {
      const referrer = userHelpers.findByReferralCode.get(refFromQuery.toUpperCase());
      if (referrer && referrer.telegram_id !== authData.id) {
        referredBy = referrer.id;
      }
    }

    userHelpers.create.run(
      authData.id, authData.username || null, authData.first_name || null,
      authData.last_name || null, authData.photo_url || null, role, hash, refCode, referredBy
    );
    user = userHelpers.findByTelegramId.get(authData.id);

    // Начисляем бонус рефереру
    if (referredBy) {
      referralHelpers.create.run(referredBy, user.id);
      userHelpers.extendPlan(referredBy, 2); // +2 дня рефереру
      logHelpers.add.run('info', `РЕФЕРАЛ: user_id:${referredBy} получил +2 дня за приглашение @${user.username || user.first_name}`, referredBy, null);
    }

    logHelpers.add.run('auth', `Новый пользователь: @${authData.username || authData.first_name} (${authData.id})`, user.id, req.ip);
  } else {
    userHelpers.update.run(
      authData.username || null, authData.first_name || null,
      authData.last_name || null, authData.photo_url || null, hash, authData.id
    );
    userHelpers.updateLastSeen.run(user.id);
    user = userHelpers.findByTelegramId.get(authData.id);
  }

  if (user.is_banned) {
    logHelpers.add.run('auth', `Попытка входа забаненного: @${user.username} (${authData.id})`, user.id, req.ip);
    return res.status(403).json({ error: `Аккаунт заблокирован. Причина: ${user.ban_reason}` });
  }

  req.session.userId = user.id;
  req.session.telegramId = user.telegram_id;
  req.session.username = user.username;
  req.session.role = user.role;

  res.json({
    success: true,
    user: {
      id: user.id, telegramId: user.telegram_id, username: user.username,
      firstName: user.first_name, lastName: user.last_name, photoUrl: user.photo_url,
      role: user.role, plan: user.plan, planExpiresAt: user.plan_expires_at,
      trafficUsed: user.traffic_used, trafficLimit: user.traffic_limit,
      referralCode: user.referral_code,
      referralLink: `${process.env.APP_URL || ''}?ref=${user.referral_code}`,
      isNewUser,
    }
  });
});

// ── GET /auth/me ─────────────────────────────────
router.get('/me', (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: 'Не авторизован' });
  userHelpers.checkExpiry(req.session.userId);
  const user = userHelpers.getById.get(req.session.userId);
  if (!user) return res.status(401).json({ error: 'Пользователь не найден' });
  if (user.is_banned) return res.status(403).json({ error: 'Заблокирован' });

  const referrals = referralHelpers.getByReferrer.all(user.id);
  const refCount = referralHelpers.countByReferrer.get(user.id).cnt;

  res.json({
    user: {
      id: user.id, telegramId: user.telegram_id, username: user.username,
      firstName: user.first_name, lastName: user.last_name, photoUrl: user.photo_url,
      role: user.role, plan: user.plan, planExpiresAt: user.plan_expires_at,
      trafficUsed: user.traffic_used, trafficLimit: user.traffic_limit,
      referralCode: user.referral_code,
      referralLink: `${process.env.APP_URL || 'https://t.me/' + process.env.TELEGRAM_BOT_USERNAME}?start=ref_${user.referral_code}`,
      referralCount: refCount,
    }
  });
});

// ── POST /auth/logout ────────────────────────────
router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

module.exports = router;
