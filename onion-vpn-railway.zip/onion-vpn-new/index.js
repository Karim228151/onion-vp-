// index.js — запускает сервер + бот одновременно
require('dotenv').config();

// Запускаем Express сервер
require('./server.js');

// Запускаем Telegram бота (с задержкой чтобы БД успела инициализироваться)
setTimeout(() => {
  try {
    require('./bot/bot.js');
  } catch (e) {
    console.error('[BOT] Ошибка запуска бота:', e.message);
    console.error('[BOT] Сервер продолжает работать без бота');
  }
}, 2000);
