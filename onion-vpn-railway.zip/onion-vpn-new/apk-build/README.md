# 📱 ONION VPN — Сборка APK файла

Для создания APK используется **Capacitor** — официальный инструмент от Ionic для оборачивания веб-приложений в нативные мобильные.

---

## ⚙️ Предварительные требования

1. **Node.js** 18+ (https://nodejs.org)
2. **Android Studio** (https://developer.android.com/studio)
3. **Java JDK 17+**
4. **Android SDK** (устанавливается вместе с Android Studio)

---

## 🚀 Шаг 1 — Установка зависимостей

```bash
cd apk-build
npm install
```

---

## 🔧 Шаг 2 — Настройка APP_URL

Отредактируй файл `apk-build/capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  server: {
    url: 'https://ВАШ_ДОМЕН.com',  // URL вашего сервера ONION VPN
  }
};
```

> ⚠️ ВАЖНО: Для APK нужен публичный HTTPS сервер (не localhost)

---

## 📦 Шаг 3 — Сборка Android проекта

```bash
cd apk-build
npx cap add android
npx cap sync android
npx cap open android
```

---

## 🏗 Шаг 4 — Сборка APK в Android Studio

1. В Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. APK будет в: `android/app/build/outputs/apk/debug/app-debug.apk`

### Или через командную строку:
```bash
cd apk-build/android
./gradlew assembleDebug
```

APK: `apk-build/android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🔑 Шаг 5 — Подписанный APK для Google Play

```bash
cd apk-build/android
./gradlew assembleRelease
```

Для подписи нужен keystore (создать: `keytool -genkey -v -keystore onion.keystore -alias onion -keyalg RSA -keysize 2048 -validity 10000`)

---

## 📋 Структура apk-build/

```
apk-build/
├── package.json          # Зависимости Capacitor
├── capacitor.config.ts   # Конфиг Capacitor
├── index.html            # Точка входа (перенаправляет на сервер)
└── android/              # Android проект (после npx cap add android)
    └── app/
        └── src/main/
            ├── AndroidManifest.xml
            └── res/
                └── values/
                    └── strings.xml
```

---

## 🎨 Иконка и splash screen

Замени файлы в `android/app/src/main/res/`:
- `mipmap-*/ic_launcher.png` — иконка приложения
- `drawable/splash.png` — splash screen

Или используй: `npx @capacitor/assets generate`

---

## 🔒 Разрешения Android

Уже добавлены в AndroidManifest:
- `INTERNET` — для соединения с сервером
- `CHANGE_NETWORK_STATE` — для VPN
- `ACCESS_NETWORK_STATE` — статус сети

---

## ❓ Частые вопросы

**Q: Приложение показывает белый экран?**  
A: Убедись что APP_URL в capacitor.config.ts указывает на рабочий HTTPS сервер

**Q: Ошибка Mixed Content?**  
A: Сервер ДОЛЖЕН работать по HTTPS, не HTTP

**Q: Как обновить APK после изменений на сервере?**  
A: Ничего делать не нужно — APK загружает актуальную версию с сервера при каждом запуске
