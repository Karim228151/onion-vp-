import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.onionvpn.app',
  appName: 'ONION VPN',
  webDir: 'www',
  server: {
    // ⚠️ ЗАМЕНИТЕ НА URL ВАШЕГО СЕРВЕРА (HTTPS обязателен для APK)
    url: 'https://your-server.com',
    cleartext: false,
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#000000',
      showSpinner: false,
    },
  },
};

export default config;
